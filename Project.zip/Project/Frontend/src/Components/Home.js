import React from 'react'
import Navbar from './NavBar'

const Home = () => {
  return (
    <div>
        <Navbar/>
    </div>
  )
}

export default Home